# Tests for conservation properties
